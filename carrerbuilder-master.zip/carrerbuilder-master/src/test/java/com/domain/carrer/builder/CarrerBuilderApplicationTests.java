package com.domain.carrer.builder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarrerBuilderApplicationTests {

	@Test
	void contextLoads() {
	}

}
