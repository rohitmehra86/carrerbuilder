package com.domain.carrer.builder.dto;

public class LogOutRequest {
  private Long userId;

  public Long getUserId() {
    return this.userId;
  }
}
