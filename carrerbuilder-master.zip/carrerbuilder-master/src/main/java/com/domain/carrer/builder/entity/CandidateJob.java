package com.domain.carrer.builder.entity;

public class CandidateJob {

}
