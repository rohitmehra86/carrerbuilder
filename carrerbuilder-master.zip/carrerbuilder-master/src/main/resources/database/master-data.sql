INSERT INTO `roles` (`id`, `name`) VALUES (1, 'ROLE_CANDIDATE');
INSERT INTO `roles` (`id`, `name`) VALUES (2, 'ROLE_RECRUITER');
INSERT INTO `roles` (`id`, `name`) VALUES (3, 'ROLE_ADMIN');
